$(".login-effect input").on("focus", function(){
	$(this).addClass("focus");
});

$(".login-effect input").on("blur", function(){
	if($(this).val() == "")
		$(this).removeClass("focus");
});

$('[name="signup_btn"]').on('click', function(){
	var uid = id.value;
	var upw = pw.value;
	var upw_check = pw_check.value;
	
	if(uid.lengh < 4){
		alert("4자리 이상의 아이디로 생성해주세요");
		id.focus();
		return;
	}
	if(upw.length < 4 || upw.length > 12){
		alert("4 ~ 12자의 비밀번호로 생성해주세요.");
		pw.focus();
		return;
	}
	if(upw != upw_check){
		alert("비밀번호가 일치하지 않습니다.");
		pw.focus();
		return;
	}
	
	$('form').submit();
});

$('#logout').on('click', function() {
	location.href="main.do?action=loginForm";
});

$('#prodmanage').on('click', function(){
	location.href="main.do?action=productForm";
});

$('#insertprodForm').on('click', function(){
	location.href="main.do?action=insertprodForm";
});

$('#searchproduct').on('click', function(){
	var name = prodname.value;
	location.href="main.do?action=searchproduct&name=" + name;
});

$('#pricesearch').on('click', function(){
	var pri = price.value;
	location.href="main.do?action=pricesearch&price=" + pri;
});