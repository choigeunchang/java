package edu.ssafy.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.ssafy.model.Member;
import edu.ssafy.model.MemberManager;
import edu.ssafy.model.Product;
import edu.ssafy.model.ProductManager;

public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ProductManager prod = ProductManager.getInstance();
	private MemberManager mem = MemberManager.getInstance();

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=utf-8");
		
		String action = req.getParameter("action");
		System.out.println(action);
		if(action.equals("login")) {
			// 로그인
			login(req, resp);
		}
		else if(action == null || action.equals("loginForm")) {
			req.getRequestDispatcher("login.jsp").forward(req, resp);
		}
		else if(action.equals("signupForm")) {
			// 회원추가 작업 해주고 메인으로
			req.getRequestDispatcher("signup.jsp").forward(req, resp);
		}
		else if(action.equals("signup")) {
			// 회원가입
			signup(req, resp);
		}
		else if(action.equals("delmember")) {
			delMember(req, resp);
		}
		else if(action.equals("logout")) {
			// 로그아웃
			logout(req, resp);
		}
		else if(action.equals("main")) {
			List<Member> list = mem.GetMemberList();
			req.setAttribute("memberList", list);
			req.getRequestDispatcher("MemberList.jsp").forward(req, resp);
		}
		else if(action.equals("productForm")) {
			// 상품목록 페이지 이동
			List<Product> list = prod.GetList();
			req.setAttribute("productlist", list);
			req.getRequestDispatcher("productmain.jsp").forward(req, resp);
		}
		else if(action.equals("insertprodForm")) {
			// 상픔등록 페이지 이동
			req.getRequestDispatcher("insertprodForm.jsp").forward(req, resp);
		}
		else if(action.equals("insertprod")) {
			insertprod(req, resp);
		}
		else if(action.equals("delproduct")) {
			// 상품정보 삭제
			deleteprod(req, resp);
		}
		else if(action.equals("searchproduct")) {
			// 상품명 검색
			listproduct(req, resp);
		}
		else if(action.equals("pricesearch")) {
			// 상품가격 검색
			pricesearch(req, resp);
		}
	}

	private void pricesearch(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int price = Integer.parseInt(req.getParameter("price"));
		List<Product> list = prod.PriceSeacrh(price);
		System.out.println(price);
		if(list != null) {
			req.setAttribute("productlist", list);
			req.getRequestDispatcher("productmain.jsp").forward(req, resp);
		}
		else {
			req.setAttribute("result", "조회 실패");
			req.getRequestDispatcher("result.jsp").forward(req, resp);
		}
	}

	private void listproduct(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name = req.getParameter("name");
		List<Product> list = prod.NumSearch(name);
		
		if(list != null) {
			req.setAttribute("productlist", list);
			req.getRequestDispatcher("productmain.jsp").forward(req, resp);
		}
		else {
			req.setAttribute("result", "조회 실패");
			req.getRequestDispatcher("result.jsp").forward(req, resp);
		}
	}

	private void deleteprod(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int num = Integer.parseInt(req.getParameter("num"));
		boolean del = prod.DeleteProd(num);
		
		if(del)
			req.getRequestDispatcher("main.do?action=productForm").forward(req, resp);
		else {
			req.setAttribute("result", num + "삭제 실패");
			req.getRequestDispatcher("result.jsp").forward(req, resp);
		}
	}

	private void insertprod(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		
		int num = Integer.parseInt(req.getParameter("num"));
		String name = req.getParameter("name");
		int price = Integer.parseInt(req.getParameter("price"));
		String entry = req.getParameter("entry");
		String info = req.getParameter("info");
		String com = req.getParameter("com");

		Product product = new Product(num, name, price, entry, info, com);
		prod.InsertProd(product);
		resp.sendRedirect("main.do?action=productForm");
	}

	private void logout(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		
		req.getSession().setAttribute("id", null);
		resp.sendRedirect("main.do?action=main");
	}

	private void delMember(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String uid = req.getParameter("uid");
		boolean del = mem.DeleteMember(uid);
		
		if(del)
			req.getRequestDispatcher("main.do?action=main").forward(req, resp);
		else {
			req.setAttribute("result", uid + "삭제 실패");
			req.getRequestDispatcher("result.jsp").forward(req, resp);
			
		}
	}

	private void signup(HttpServletRequest req, HttpServletResponse resp) throws IOException {

		String uid = req.getParameter("uid");
		String pw = req.getParameter("pw");
		String name = req.getParameter("name");
		String phone = req.getParameter("phone");
		String email = req.getParameter("email");
		String addr = req.getParameter("addr");
		String birth = req.getParameter("birth");

		Member member = new Member(uid, pw, name, phone, email, addr, birth);
		mem.InsertMember(member);
		resp.sendRedirect("main.do?action=loginForm");	
	}

	private void login(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String uid = req.getParameter("uid");
		String pw = req.getParameter("pw");
		
		if(pw.equals(mem.GetMember(uid).getPw())) {
			// 로그인 성공
			req.getSession().setAttribute("id", uid);
			resp.sendRedirect("main.do?action=main");
		}
		else {
			resp.sendRedirect("main.do?action=loginForm");
		}
	}
}
