package edu.ssafy.model;

public class Product {
	
	private int num;
	private String name;
	private int price;
	private String entry;
	private String info;
	private String com;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getEntry() {
		return entry;
	}
	public void setEntry(String entry) {
		this.entry = entry;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getCom() {
		return com;
	}
	public void setCom(String com) {
		this.com = com;
	}

	public Product() {}
	public Product(int num, String name, int price, String entry, String info, String com) {
		this.num = num;
		this.name = name;
		this.price = price;
		this.entry = entry;
		this.info = info;
		this.com = com;
	}
	@Override
	public String toString() {
		return "num=" + num + ", name=" + name + ", price=" + price
				+ ", entry=" + entry + ", info=" + info + ", com=" + com;
	}
}
