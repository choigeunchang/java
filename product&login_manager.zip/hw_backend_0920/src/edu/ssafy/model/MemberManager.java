package edu.ssafy.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MemberManager {

	// 싱글톤
	public MemberManager() {}
	private static MemberManager member = new MemberManager();
	public static MemberManager getInstance() {
		return member;
	}
	
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;
	
	// 회원정보 입력
	public boolean InsertMember(Member m) {
		
		String query = "insert into members values(?, ?, ?, ?, ?, ?, ?)";
		boolean result = false;
		
		try {
			con = ConnectionProxy.getConnection();
			pst = con.prepareStatement(query);
			pst.setString(1, m.getUid());
			pst.setString(2, m.getPw());
			pst.setString(3, m.getName());
			pst.setString(4, m.getPhone());
			pst.setString(5, m.getEmail());
			pst.setString(6, m.getAddr());
			pst.setString(7, m.getBirth());
			pst.execute();
			result = true;
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Insert Failed in Member...");
			result = false;
		} finally {
			close();
		}
		
		return result;
	}
	
	// 회원목록
	public List<Member> GetMemberList(){
		
		String query = "select *from members";
		Member m = null;
		List<Member> list = new ArrayList<>();
		
		try {
			con = ConnectionProxy.getConnection();
			pst = con.prepareStatement(query);
			rs = pst.executeQuery();
			
			while(rs.next()) {
				m = new Member();
				m.setUid(rs.getString("uid"));
				m.setPw(rs.getString("pw"));
				m.setName(rs.getString("name"));
				m.setPhone(rs.getString("phone"));
				m.setEmail(rs.getString("email"));
				m.setAddr(rs.getString("addr"));
				m.setBirth(rs.getString("birth"));
				list.add(m);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Getting List Failed in Member...");
		} finally {
			close();
		}
		
		return list;
	}
	
	// 아이디로 회원검색
	public Member GetMember(String userid) {
		
		String query = "select *from members where uid=?";
		Member m = null;
		
		try {
			con = ConnectionProxy.getConnection();
			pst = con.prepareStatement(query);
			pst.setString(1, userid);
			rs = pst.executeQuery();
			
			if(rs.next()) {
				m = new Member();
				m.setName(rs.getString("name"));
				m.setUid(rs.getString("uid"));
				m.setPw(rs.getString("pw"));
				m.setPhone(rs.getString("phone"));
				m.setEmail(rs.getString("email"));
				m.setAddr(rs.getString("addr"));
				m.setBirth(rs.getString("birth"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Getting data failed from uid...");
		} finally {
			close();
		}
		return m;
	}
	
	// 아이디로 회원 삭제
	public boolean DeleteMember(String uid) {
		
		String query = "delete from members where uid=?";
		boolean result = false;
		
		try {
			con = ConnectionProxy.getConnection();
			pst = con.prepareStatement(query);
			pst.setString(1, uid);
			pst.execute();
			result = true;
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Delete Failed in Member...");
			result = false;
		} finally {
			close();
		}
		
		return result;
	}
	
	
	public void close() {
		
		try {
			if(rs != null)
				rs.close();
			if(pst != null)
				pst.close();
			if(con != null)
				con.close();
		} catch(SQLException e){
			e.printStackTrace();
			System.out.println("Close Failed in Member...");
		}
	}
}
