package edu.ssafy.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductManager {
	
	// 싱글톤
	public ProductManager() {}
	private static ProductManager prod = new ProductManager();
	public static ProductManager getInstance() {
		return prod;
	}
	
	private Connection con;
	private PreparedStatement pst;
	private ResultSet rs;
	
	// 상품정보 입력
	public boolean InsertProd(Product p) {
		
		String query = "insert into product values(?, ?, ?, ?, ?, ?)";
		boolean result = false;
		
		try {
			con = ConnectionProxy.getConnection();
			pst = con.prepareStatement(query);
			pst.setInt(1, p.getNum());
			pst.setString(2, p.getName());
			pst.setInt(3, p.getPrice());
			pst.setString(4, p.getEntry());
			pst.setString(5, p.getInfo());
			pst.setString(6, p.getCom());
			pst.execute();
			result = true;
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Insert Failed in Product...");
			result = false;
		} finally {
			close();
		}
		
		return result;
	}
	
	// 상품번호로 조회
	public List<Product> NumSearch(String name) {
		
		String query = "select *from product where name=?";
		Product p = null;
		List<Product> list = new ArrayList<>();
		
		try {
			con = ConnectionProxy.getConnection();
			pst = con.prepareStatement(query);
			pst.setString(1, name);
			rs = pst.executeQuery();
			
			while(rs.next()) {
				p = new Product();
				p.setNum(rs.getInt("num"));
				p.setName(rs.getString("name"));
				p.setPrice(rs.getInt("price"));
				p.setEntry(rs.getString("entry"));
				p.setInfo(rs.getString("info"));
				p.setCom(rs.getString("com"));
				list.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Name Search Failed in Product...");
		} finally {
			close();
		}
		
		return list;
	}
	
	public List<Product> PriceSeacrh(int price){
		
		String query = "select *from product where price<=?";
		Product p = null;
		List<Product> list = new ArrayList<>();
		
		try {
			con = ConnectionProxy.getConnection();
			pst = con.prepareStatement(query);
			pst.setInt(1, price);
			rs = pst.executeQuery();
			
			while(rs.next()) {
				p = new Product();
				p.setNum(rs.getInt("num"));
				p.setName(rs.getString("name"));
				p.setPrice(rs.getInt("price"));
				p.setEntry(rs.getString("entry"));
				p.setInfo(rs.getString("info"));
				p.setCom(rs.getString("com"));
				list.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Price Search Failed in Product...");
		} finally {
			close();
		}
		
		return list;
	}
	
	// 목록조회
	public List<Product> GetList(){
		
		String query = "select *from product";
		Product p = null;
		List<Product> list = new ArrayList<>();
		
		try {
			con = ConnectionProxy.getConnection();
			pst = con.prepareStatement(query);
			rs = pst.executeQuery();
			
			while(rs.next()) {
				p = new Product();
				p.setNum(rs.getInt("num"));
				p.setName(rs.getString("name"));
				p.setPrice(rs.getInt("price"));
				p.setEntry(rs.getString("entry"));
				p.setInfo(rs.getString("info"));
				p.setCom(rs.getString("com"));
				list.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Getting List Failed in Product...");
		} finally {
			close();
		}
		
		return list;
	}
	
	// 상품번호로 상품 삭제
	public boolean DeleteProd(int num) {
		
		String query = "delete from product where num=?";
		boolean result = false;
		
		try {
			con = ConnectionProxy.getConnection();
			pst = con.prepareStatement(query);
			pst.setInt(1, num);
			pst.execute();
			result = true;
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Delete Failed in Product...");
			result = false;
		} finally {
			close();
		}
		
		return result;
	}
	
	public void close() {
		
		try {
			if(rs != null)
				rs.close();
			if(pst != null)
				pst.close();
			if(con != null)
				con.close();
		} catch(SQLException e){
			e.printStackTrace();
			System.out.println("Close Failed in Product...");
		}
	}
	
	
}
