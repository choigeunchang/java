package edu.ssafy.model;

import java.sql.*;

public class ConnectionProxy {

	// 이 클래스의 객체 선언을 하지 않아도 static으로 선언 했기 때문에 이 함수를 불러올 수 있다.
	public static Connection getConnection() throws SQLException {
		
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ving?serverTimezone="
					+ "UTC&useUniCode=yes&characterEncoding=UTF-8","ving", "1111");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver Loading Failed...");
		}
		
		return con;
	}
}
