use ving;

create table product(
	num integer primary key,
    name varchar(20),
    price integer,
    entry varchar(20),
    info varchar(20),
    com varchar(20)
);
desc product;

create table members(
	uid varchar(20) primary key,
    pw varchar(20),
    name varchar(20),
    phone varchar(20),
    email varchar(20),
    addr varchar(20),
    birth varchar(20)
);
desc members;
select *from members;
delete from members;